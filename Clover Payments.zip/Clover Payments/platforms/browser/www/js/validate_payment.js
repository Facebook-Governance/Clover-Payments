$('#block_id').change(function () {
	var block_id = $("#block_id").val();
	var flatSelect = $('#flat_id');
	if (block_id != null && block_id != '') {
		// Next 2 lines will blank-out the Cities drop down list. Do this so it doesn't
		// contain "stale" data	
		flatSelect .empty();
		flatSelect .append($('<option value="" selected="selected">Select Flat</option>'));
		$.getJSON('http://108.175.8.71/gatedcommunity.com/payment/ws/get_flats_ws.php', { format: 'json', block_id: block_id }, function (myData) {
			$.each(myData, function (index, itemData) {
				flatSelect.append($('<option/>', {
					value: itemData.flat_no,
					text: itemData.flat_no
				}));
			});
		});
	};
});
function getOwnerInfo(){
	var block_id=$('#block_id').val();
	var flat_id=$('#flat_id').val();
	if(block_id!=''&&flat_id!=''){
		$.ajax({
			type: "POST",
			url: "http://108.175.8.71/gatedcommunity.com/payment/ws/getowner.php",
			data: {block_id:block_id, flat_id:flat_id},
			cache: false,
			success: function(resData){
				//alert(resData.owner_name+'|'+resData.owner_phone);
				if(resData.owner_id!=null){
					$('#owner_id').val(resData.owner_id);
					$('#owner_name').val(resData.owner_name);
					$('#owner_phone').val(resData.owner_phone);
				}else{
					$('#owner_id').val('');
					$('#owner_name').val('');
					$('#owner_phone').val('');
				}
			}
		});	
	}
}
function validateForm(){
	var block_id=$('#block_id').val();
	var flat_id=$('#flat_id').val();
	var owner_name=$('#owner_name').val();
	var owner_id=$('#owner_id').val();
	var owner_phone=$('#owner_phone').val();
	var owner_other_phone=$('#owner_other_phone').val();
	var payment_for=$('#payment_for').val();
	var other_desc=$('#other_desc').val();
	var amount=$('#amount').val();
	var payment_type=$('#payment_type').val();
	var reference_no=$('#reference_no').val();
	var receipt_no=$('#receipt_no').val();
	//var reference_no=$('#reference_no').val();
	var formValid=true;
	if(block_id==''){
		$('#block_id').css('border-color','red');
		formValid=false;
	}else{
		$('#block_id').css('border-color','');
	}
	if(flat_id==''){
		$('#flat_id').css('border-color','red');
		formValid=false;
	}else{
		$('#flat_id').css('border-color','');
	}
	if(owner_name==''){
		$('#owner_name').css('border-color','red');
		formValid=false;
	}else{
		$('#owner_name').css('border-color','');
	}
	if(owner_phone==''){
		$('#owner_phone').css('border-color','red');
		formValid=false;
	}else{
		$('#owner_phone').css('border-color','');
	}
	if(payment_for==''){
		$('#payment_for').css('border-color','red');
		formValid=false;
	}else{
		$('#payment_for').css('border-color','');
		if(payment_for==3){
			if(other_desc==''){
				$('#other_desc').css('border-color','red');
				formValid=false;
			}else{
				$('#other_desc').css('border-color','');
			}
		}
	}
	if(amount==''){
		$('#amount').css('border-color','red');
		formValid=false;
	}else{
		$('#amount').css('border-color','');
	}
	if(payment_type==''){
		$('#payment_type').css('border-color','red');
		formValid=false;
	}else{
		$('#payment_type').css('border-color','');
		if(payment_type==2||payment_type==3){
			if(reference_no==''){
				$('#reference_no').css('border-color','red');
				formValid=false;
			}else{
				$('#reference_no').css('border-color','');
			}
		}
	}
	if(receipt_no==''){
		$('#receipt_no').css('border-color','red');
		formValid=false;
	}else{
		$('#receipt_no').css('border-color','');
	}
	if(formValid==false){
		//alert('not ok');
		return false;
	}else{
		//alert('ok');
		$("#submit_form").attr('disabled','disabled');
		$("#submit_form").css('cursor','not-allowed');
		$.ajax({
			url:"http://108.175.8.71/gatedcommunity.com/payment/ws/save_payment.php",
			type:"POST",
			data:{block_id:block_id,flat_id:flat_id,owner_id:owner_id,owner_name:owner_name,owner_phone:owner_phone,owner_other_phone:owner_other_phone,payment_for:payment_for,other_desc:other_desc,amount:amount,payment_type:payment_type,reference_no:reference_no,receipt_no:receipt_no},
			cache: false,
			success:function(html) {
				$('#block_id').prop('selectedIndex','');
				$('#flat_id').prop('selectedIndex','');
				$('#owner_id').val('');
				$('#owner_name').val('');
				$('#owner_phone').val('');
				$('#owner_other_phone').val('');
				$('#payment_for').prop('selectedIndex','');
				$('#other_desc').val('');
				$('#amount').val('');
				$('#payment_type').prop('selectedIndex','');
				$('#reference_no').val('');
				$('#receipt_no').val('');
				obj = JSON.parse(JSON.stringify(html));
				if(obj.status!=0){
					$("#status_div").css('color','green');
					$("#status_div").html('SMS has been sent.');
				}
				else{
					$("#status_div").css('color','red');
					$("#status_div").html('Update unsuccessful!');
				}
				setTimeout(function() {
					$("#status_div").hide();
				}, 3000);
				$('html, body').animate({scrollTop: $('#status_div').offset().top  }, 'slow');
				$("#submit_form").attr('disabled',false);
				$("#submit_form").css('cursor','pointer');
			}
		});
	} 
	//return true;
}
$( document ).ready(function() {
	$( "#payment_for" ).change(function() {
		if($( "#payment_for" ).val()==3){
			$( "#other_name_block" ).css('display','block');
		}else{
			$( "#other_name_block" ).css('display','none');
		}
	});
	$( "#payment_type" ).change(function() {
		if($( "#payment_type" ).val()==2||$( "#payment_type" ).val()==3){
			$( "#reference_no_block" ).css('display','block');
		}else{
			$( "#reference_no_block" ).css('display','none');
		}
	});
});