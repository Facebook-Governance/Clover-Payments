function validateForm(){
	var username=$('#username').val();
	var password=$('#password').val();
	if(username==''||password==''){
		if(username==''){
			$('#username').css('border-color','red');
		}else{
			$('#username').css('border-color','');
		}
		if(password==''){
			$('#password').css('border-color','red');
		}else{
			$('#password').css('border-color','');
		}
	}else{
		$("#submit_form").attr('disabled','disabled');
		$("#submit_form").css('cursor','not-allowed');
		$.ajax({
			url:"http://108.175.8.71/gatedcommunity.com/payment/ws/get_user.php",
			type:"POST",
			data:{username:username,password:password},
			cache: false,
			success:function(html) {
				obj = JSON.parse(JSON.stringify(html));
				if(obj.status!=0){
					var user_id = obj.user_id;
					sessionStorage.setItem("user_id", user_id);
					window.location='payment.html';
				}
				else{
					$("#error_msg").html('Invalid Username or Password.');
				}
			}
		});
	}
}